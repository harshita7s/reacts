import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Parent from './parent';
import registerServiceWorker from './registerServiceWorker';

var template =  <Parent>
                    <br/>
                    <button>register</button>
                    <br/>
                    this is a sample content
                </Parent>

ReactDOM.render(template, document.getElementById('root'));
registerServiceWorker();
