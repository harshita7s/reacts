import React, { Component } from 'react';
import DataList from './dataList';
import './App.css';
class App extends Component {

  /*Setting initial state*/
  state = {
    items: []
  };

  /*Handling add data function*/
  addData = (e) => {
    var newItem = {
      text: this.data.value,
      key: Date.now()
    };
    this.setState((prevState) => {
      return {
        items: prevState.items.concat(newItem)

      };
    })

    this.data.value = "";
    console.log(this.state.items);
    e.preventDefault();
  }


  /*Rendering the view*/
  render() {
    return (
      <div className="App">
        <form>

          <label>Name</label>
          <input type="text" ref={(input) => this.data = input} />

          <button onClick={this.addData.bind(this)}>Add</button>

        </form>
        <br/>
        <DataList text={this.state.items}></DataList>
      </div>
    );
  }
}

export default App;
