import React, { Component } from 'react';
import Samsung_J3Pro from '../img/Samsung_J3Pro.jpg'
import Samsung_J6 from '../img/Samsung_J6.jpg'
import Samsung_On7 from '../img/Samsung_On7.jpg'
import Samsung_On7Prime from '../img/Samsung_On7Prime.jpg'

class Samsung extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            imgs: [ Samsung_J3Pro, Samsung_J6, Samsung_On7, Samsung_On7Prime ]
         }
    }
    render() { 
        let images = this.state.imgs.map((image,index) => {
             return <img className="img-thumbnail" width="300px" height="500px" src={image} alt={index+1} key={index}/>
        })
        return ( 
            <div>
            <h2>Samsung</h2>
            {images}
            </div>
         );
    }
}
 
export default Samsung;