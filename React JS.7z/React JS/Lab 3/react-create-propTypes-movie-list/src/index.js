import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import MovieList from './MovieList';
import registerServiceWorker from './registerServiceWorker';


import HarryPotter from './HarryPotter.jpeg';
import Avengers from './Avengers.jpeg'

var movies=[
            {
                'imageName':HarryPotter,
                'ticketPrice':300 ,
                'movieName':'Harry Potter'
            },
            {
                'imageName':Avengers,
                'ticketPrice':450 ,
                'movieName':'Avengers'
            }
];


ReactDOM.render(<MovieList movies={movies} />, document.getElementById('root'));
registerServiceWorker();
