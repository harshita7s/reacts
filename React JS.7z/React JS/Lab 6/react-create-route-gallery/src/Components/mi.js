import React, { Component } from 'react';
import Mi_5A from '../img/Mi_5A.jpg'
import Mi_A1 from '../img/Mi_A1.jpg'
import Mi_MI3 from '../img/Mi_MI3.jpg'
import Mi_Note5 from '../img/Mi_Note5.jpg'

class Mi extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            imgs: [ Mi_5A, Mi_A1, Mi_MI3, Mi_Note5 ]
         }
    }
    render() { 
        let images = this.state.imgs.map((image,index) => {
             return (<span><img className="img-thumbnail" width="200px" height="400px" src={image} alt={index+1} key={index}/>&nbsp;&nbsp;</span>);
        })
        return ( 
            <div>
            <h3>mi1</h3>
            {images}
            </div>
         );
    }
}
 
export default Mi;