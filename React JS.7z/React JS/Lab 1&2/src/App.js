import React, { Component } from 'react';
import User from './User.jpg';
import Guest from './Guest.jpg'
class App extends Component {

  render() {
    var display;
    var tag;
    if(this.props.display){
      tag= <img src={User} title='This is user' alt='This is user'/>;
      display='true';
    }
    else{
      tag= <img src={Guest} title='This is guest' alt='This is guest'/>;
      display='false';
    }
    return (
        <div style={{marginLeft:'200px'}}>
               <h2 >React Basic App</h2>
               <h3>The value of this.props is {display}</h3>
               {tag}
        </div>
    );
  }
}

export default App;
