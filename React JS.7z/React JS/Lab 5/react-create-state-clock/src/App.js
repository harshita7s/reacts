import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(){
    super();
    this.state = {
      time : new Date(),
      display: "IGATE"
    }
  }
  
/*When the clock will start to tick, this method will be called*/
  currentTime(){
    this.setState({
      time: new Date(),
      display: "CAPGEMINI"
    })
  }

  /*set the clock interval in lifecycle method*/
  componentDidMount(){
    setInterval(()=>this.currentTime(),1000);
  }
  
  render() {
    return (
      <div className="App">
        <h1>{this.state.display}</h1>
        <div className="container">
        <h1>{this.state.time.toLocaleTimeString()}</h1>
        </div>
      </div>
    );
  }
}

export default App;
