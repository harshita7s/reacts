import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';

var stringArray=['React','Children','Api','Print','String','Array','Using','ForEach'];
var template= <App>
                 {stringArray}
              </App>

ReactDOM.render(template, document.getElementById('root'));
registerServiceWorker();
