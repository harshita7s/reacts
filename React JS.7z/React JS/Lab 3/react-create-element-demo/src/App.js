import React from 'react';
import './App.css';

/*USing create-react-class package's method to create a component*/
var createClass= require('create-react-class');

var Welcome= createClass({
  render: function(){
    return(
      <h1>Welcome to Capgemini</h1>
    );
  }
});

export default Welcome;
