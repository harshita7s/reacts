import React,{Component,Children} from 'react';

class Parent extends Component{
  render(){

    let children = this.props.children
    var styles = {
                    backgroundColor:'lavender',
                    fontWeight:'bold'
                 };

    return(
      <div>

        --Count the number of children--
        <h3>Total Children: {Children.count(children)}</h3>

        --Display Type of Children--
        <h3>
        {Children.map(children, (child, i) => {
          return (child.type+" ")
        })}
        </h3>

        --Display Children--
        <h3 style={styles}>{children}</h3>

        --Restrict the child to single element use the method below--
        <h3>React.Children.only(this.props.children)</h3>
      </div>
    )
  }
}

export default Parent;